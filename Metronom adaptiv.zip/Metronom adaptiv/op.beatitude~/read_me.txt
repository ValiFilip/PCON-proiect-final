beatitude~ --- beat tracking abstraction.

---------------------
The algorithm uses "some kind" of empirical threshold based analysis based on "some kind" of bark spectrum. It is inspired from the Tristan Jehan's beat~ external but dose work on different rythmic situations.

Use it for simple automatic spychoacoustic sound segmentation and tempo finding.

Written by Olivier Pasquet_2005.